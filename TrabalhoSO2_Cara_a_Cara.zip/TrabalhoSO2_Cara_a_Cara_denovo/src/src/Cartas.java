package src;

import java.util.ArrayList;
import java.util.List;

public class Cartas {

    public List<Personagens> todosPersonagens() {
        List<Personagens> perso = new ArrayList<>();
        
        Personagens p = new Personagens();
        p.setNome("Jorge");
        p.setCabelo("liso");
        p.setSexo("masculino");
        p.setCorCabelo("branco");
        p.setCorOlhos("castanhos");
        p.setCorPele("branca");
        p.setChapeu("sim");
        p.setOculos("nao");
        perso.add(p);
        
        p = new Personagens();
        p.setNome("Beto");
        p.setCabelo("liso");
        p.setSexo("masculino");
        p.setCorCabelo("marrom");
        p.setCorOlhos("castanhos");
        p.setCorPele("branca");
        p.setChapeu("sim");
        p.setOculos("nao");
        perso.add(p);
        
        p = new Personagens();
        p.setNome("Ana");
        p.setCabelo("cacheado");
        p.setSexo("feminino");
        p.setCorCabelo("preto");
        p.setCorOlhos("castanhos");
        p.setCorPele("negra");
        p.setChapeu("nao");
        p.setOculos("nao");
        perso.add(p);
        
        p = new Personagens();
        p.setNome("Pedro");
        p.setCabelo("liso");
        p.setSexo("masculino");
        p.setCorCabelo("branco");
        p.setCorOlhos("azuis");
        p.setCorPele("branca");
        p.setChapeu("nao");
        p.setOculos("nao");
        perso.add(p);
        
        p = new Personagens();
        p.setNome("Paulo");
        p.setCabelo("liso");
        p.setSexo("masculino");
        p.setCorCabelo("branco");
        p.setCorOlhos("castanhos");
        p.setCorPele("branca");
        p.setChapeu("nao");
        p.setOculos("sim");
        perso.add(p);
        
        p = new Personagens();
        p.setNome("Daniel");
        p.setCabelo("liso");
        p.setSexo("masculino");
        p.setCorCabelo("amarelo");
        p.setCorOlhos("castanhos");
        p.setCorPele("branca");
        p.setChapeu("nao");
        p.setOculos("nao");
        perso.add(p);
        
        p = new Personagens();
        p.setNome("Clara");
        p.setCabelo("liso");
        p.setSexo("feminino");
        p.setCorCabelo("preto");
        p.setCorOlhos("castanhos");
        p.setCorPele("morena");
        p.setChapeu("sim");
        p.setOculos("sim");
        perso.add(p);
        
        p = new Personagens();
        p.setNome("Helio");
        p.setCabelo("cacheado");
        p.setSexo("masculino");
        p.setCorCabelo("preto");
        p.setCorOlhos("castanhos");
        p.setCorPele("morena");
        p.setChapeu("nao");
        p.setOculos("nao");
        perso.add(p);
        
        p = new Personagens();
        p.setNome("Ricardo");
        p.setCabelo("liso");
        p.setSexo("masculino");
        p.setCorCabelo("marrom");
        p.setCorOlhos("castanhos");
        p.setCorPele("branca");
        p.setChapeu("nao");
        p.setOculos("nao");
        perso.add(p);
        
        p = new Personagens();
        p.setNome("Roberto");
        p.setCabelo("liso");
        p.setSexo("masculino");
        p.setCorCabelo("marrom");
        p.setCorOlhos("azuis");
        p.setCorPele("branca");
        p.setChapeu("nao");
        p.setOculos("nao");
        perso.add(p);
        
        p = new Personagens();
        p.setNome("Zeca");
        p.setCabelo("cacheado");
        p.setSexo("masculino");
        p.setCorCabelo("amarelo");
        p.setCorOlhos("castanhos");
        p.setCorPele("branca");
        p.setChapeu("nao");
        p.setOculos("sim");
        perso.add(p);
        
        p = new Personagens();
        p.setNome("Luis");
        p.setCabelo("cacheado");
        p.setSexo("masculino");
        p.setCorCabelo("preto");
        p.setCorOlhos("castanhos");
        p.setCorPele("negra");
        p.setChapeu("nao");
        p.setOculos("nao");
        perso.add(p);
        
        p = new Personagens();
        p.setNome("Henrique");
        p.setCabelo("liso");
        p.setSexo("masculino");
        p.setCorCabelo("amarelo");
        p.setCorOlhos("castanhos");
        p.setCorPele("branca");
        p.setChapeu("sim");
        p.setOculos("nao");
        perso.add(p);
        
        p = new Personagens();
        p.setNome("Chico");
        p.setCabelo("cacheado");
        p.setSexo("masculino");
        p.setCorCabelo("preto");
        p.setCorOlhos("castanhos");
        p.setCorPele("morena");
        p.setChapeu("nao");
        p.setOculos("nao");
        perso.add(p);
        
        p = new Personagens();
        p.setNome("Joao");
        p.setCabelo("liso");
        p.setSexo("masculino");
        p.setCorCabelo("branco");
        p.setCorOlhos("castanhos");
        p.setCorPele("branca");
        p.setChapeu("nao");
        p.setOculos("sim");
        perso.add(p);
        
        p = new Personagens();
        p.setNome("Marcos");
        p.setCabelo("cacheado");
        p.setSexo("masculino");
        p.setCorCabelo("marrom");
        p.setCorOlhos("castanhos");
        p.setCorPele("branca");
        p.setChapeu("nao");
        p.setOculos("nao");
        perso.add(p);
        
        p = new Personagens();
        p.setNome("Sonia");
        p.setCabelo("liso");
        p.setSexo("feminino");
        p.setCorCabelo("branco");
        p.setCorOlhos("castanhos");
        p.setCorPele("branca");
        p.setChapeu("nao");
        p.setOculos("nao");
        perso.add(p);
        
        p = new Personagens();
        p.setNome("Carlos");
        p.setCabelo("liso");
        p.setSexo("masculino");
        p.setCorCabelo("amarelo");
        p.setCorOlhos("castanhos");
        p.setCorPele("branca");
        p.setChapeu("nao");
        p.setOculos("nao");
        perso.add(p);
        
        p = new Personagens();
        p.setNome("Maria");
        p.setCabelo("liso");
        p.setSexo("feminino");
        p.setCorCabelo("marrom");
        p.setCorOlhos("castanhos");
        p.setCorPele("branca");
        p.setChapeu("sim");
        p.setOculos("nao");
        perso.add(p);
        
        p = new Personagens();
        p.setNome("Tony");
        p.setCabelo("liso");
        p.setSexo("masculino");
        p.setCorCabelo("preto");
        p.setCorOlhos("azuis");
        p.setCorPele("branca");
        p.setChapeu("nao");
        p.setOculos("sim");
        perso.add(p);
        
        p = new Personagens();
        p.setNome("Fernando");
        p.setCabelo("cacheado");
        p.setSexo("masculino");
        p.setCorCabelo("preto");
        p.setCorOlhos("castanhos");
        p.setCorPele("negra");
        p.setChapeu("nao");
        p.setOculos("nao");
        perso.add(p);
        
        p = new Personagens();
        p.setNome("Alfredo");
        p.setCabelo("liso");
        p.setSexo("masculino");
        p.setCorCabelo("preto");
        p.setCorOlhos("azuis");
        p.setCorPele("morena");
        p.setChapeu("nao");
        p.setOculos("nao");
        perso.add(p);
        
        p = new Personagens();
        p.setNome("Lucia");
        p.setCabelo("liso");
        p.setSexo("masculino");
        p.setCorCabelo("amarelo");
        p.setCorOlhos("azuis");
        p.setCorPele("branca");
        p.setChapeu("nao");
        p.setOculos("nao");
        perso.add(p);
        
        p = new Personagens();
        p.setNome("Edu");
        p.setCabelo("liso");
        p.setSexo("masculino");
        p.setCorCabelo("preto");
        p.setCorOlhos("castanhos");
        p.setCorPele("branca");
        p.setChapeu("nao");
        p.setOculos("nao");
        perso.add(p);
        
        return perso;
    }
}
